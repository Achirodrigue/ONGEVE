@extends('dashboard.geststock.layout.app')
@section('body')


  @include('include.message.dashboard')

  <main id="content" role="main" class="main">
    <!-- Content -->
    <div class="content container-fluid">
      <!-- Page Header -->
      <div class="page-header">
        <div class="row align-items-center mb-3">
          <div class="col-sm mb-2 mb-sm-0">
            <h1 class="page-header-title">Nombre de factures client établie <span class="badge bg-soft-dark text-dark ms-2">{{ $clientdevis->count() }}</span></h1>
          </div>
        </div>
        <!-- End Row -->

        <!-- Nav Scroller -->
        <div class="js-nav-scroller hs-nav-scroller-horizontal">
          <span class="hs-nav-scroller-arrow-prev" style="display: none;">
            <a class="hs-nav-scroller-arrow-link" href="javascript:;">
              <i class="bi-chevron-left"></i>
            </a>
          </span>

          <span class="hs-nav-scroller-arrow-next" style="display: none;">
            <a class="hs-nav-scroller-arrow-link" href="javascript:;">
              <i class="bi-chevron-right"></i>
            </a>
          </span>

          <!-- Nav -->
          <ul class="nav nav-tabs page-header-tabs" id="pageHeaderTab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" href="#">
                Toutes les factures etablies
                <span class="badge bg-soft-dark text-dark rounded-pill ms-1">{{ $clientdevis->count() }}</span>
              </a>
            </li>
          </ul>
          <!-- End Nav -->
        </div>
        <!-- End Nav Scroller -->
      </div>
      <!-- End Page Header -->

      <!-- Card -->
       <div class="card card-table">
          @if($clientdevis->count() > 0)
            <!-- Header -->
            <div class="card-header card-header-content-md-between">
              <div class="mb-2 mb-md-0 w-100">
                <form>
                  <!-- Search -->
                  <div class="input-group input-group-merge input-group-flush">
                    <div class="input-group-prepend input-group-text">
                      <i class="bi-search"></i>
                    </div>
                    <input id="datatableSearch" type="search" class="form-control" placeholder="Rechercher une facture" aria-label="Search users">
                  </div>
                  <!-- End Search -->
                </form>
              </div>
              
            </div>
            <!-- End Header -->

            <!-- Table -->
            <div class="table-responsive datatable-custom">
              <table id="datatable" class="table table-bordered table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table" style="width: 100%" data-hs-datatables-options='{
                   "columnDefs": [{
                      "targets": [0],
                      "orderable": false
                    }],
                   "order": [],
                   "info": {
                     "totalQty": "#datatableWithPaginationInfoTotalQty"
                   },
                   "search": "#datatableSearch",
                   "entries": "#datatableEntries",
                   "pageLength": 12,
                   "isResponsive": false,
                   "isShowPaging": false,
                   "pagination": "datatablePagination"
                 }'>
                <thead class="thead-light">
                  <tr>
                    <th>N°</th>
                    <th>Type facture</th>
                    <th>Commercial</th>
                    <th>N° facture</th>
                    <th>Date</th>
                    <th>Client</th>
                    <th>Tva</th>
                    <th>Frais</th>
                    <th>Total à payer</th>
                    <th>Déjà payer</th>
                    <th>Détails</th>
                    <th>Bon commande</th>
                    <th>Infos facture</th>
                    @if(auth()->user()->role)
                      <th>Action</th>
                    @endif
                    <th>N°</th>
                  </tr>
                </thead>

                <tbody>
                  @php $n=1; @endphp
                  @foreach($clientdevis as $clientdevis)
                    @php $a=$n; @endphp
                    <tr>
                      <td class="fw-bold">{{ $n++ }}</td>
                      <td>
                        <div class="btn-group" role="group">
                          <a class="btn @if($clientdevis->TDF == null) btn-secondary @elseif($clientdevis->TDF == 1) btn-warning @else btn-danger @endif btn-sm" href="#" data-bs-toggle="modal" data-bs-target="#deleteClientDevis{{ $clientdevis->id }}">
                            @if($clientdevis->TDF == null) Vente @elseif($clientdevis->TDF == 1) Location @else Prestation @endif
                          </a>
                        </div>
                      </td>
                      <td class="fw-bold">{{ $clientdevis->commercial->nom }} {{ $clientdevis->commercial->prenom }}</td>
                      <td class="fw-bold">{{ $clientdevis->numero_devis }}</td>
                      <td class="fw-bold">{{ $clientdevis->updated_at->format('d/m/Y H:i') }}</td>
                      <td class="fw-bold">{{ $clientdevis->client->nom }}</td>
                      <td class="fw-bold">{{ getprice($clientdevis->tva) }}F</td>
                      <td class="text-center fw-bold">{{ getpricefr($clientdevis->frais) }}</td>
                      <td class="fw-bold">{{ getprice($clientdevis->total_payer) }}F</td>
                      <td class="fw-bold">{{ getprice($clientdevis->versement) }}F</td>
                      <td class="text-center">
                        <div class="btn-group" role="group">
                          <a class="btn btn-white btn-sm" href="#" data-bs-toggle="modal" data-bs-target="#infoClientdevis{{ $clientdevis->id }}">
                              <i class="bi-eye me-1"></i>
                          </a>
                        </div>
                      </td>
                      <td class="text-center">
                        <div class="btn-group" role="group">
                          @if($clientdevis->clientdevisbon)
                            <a class="btn btn-white btn-sm" target="_blank" href="{{ asset(Storage::url($clientdevis->clientdevisbon->bon)) }}">
                              <i class="bi-eye me-1"></i> Voir
                            </a>
                          @else
                            <a class="btn btn-white btn-sm" href="#" data-bs-toggle="modal" data-bs-target="#adddevisbon{{ $clientdevis->id }}">
                              <i class="bi-printer me-1"></i> Associer
                            </a>
                          @endif
                        </div>
                      </td>
                      <td>
                        @php 
                          $produit = null;
                          $prestation = null;
                          if($clientdevis->TDF != 2) { if($clientdevis->clientdevisprods->count() > 0) { $produit = 1; } }
                          else { if($clientdevis->clientdevisprestations->count() > 0) { $prestation = 1; } }
                        @endphp
                        @if($produit || $prestation)
                          <div class="btn-group" role="group">
                            <a class="btn btn-white btn-sm" href="{{ route('geststock.facture.client.detail', $clientdevis) }}">
                              <i class="bi-printer me-1"></i> Details
                            </a>
                          </div>
                        @else
                          Aucune prestation
                        @endif
                      </td>
                      @if(auth()->user()->role)
                        <td>
                          <div class="btn-group" role="group">
                            <a class="btn btn-white btn-sm" href="#">
                              Derouler
                            </a>

                            <!-- Button Group -->
                            <div class="btn-group">
                              <button type="button" class="btn btn-white btn-icon btn-sm dropdown-toggle dropdown-toggle-empty" id="productsEditDrop{{ $clientdevis->id }}down" data-bs-toggle="dropdown" aria-expanded="true"></button>

                              <div class="dropdown-menu dropdown-menu-top mt-1" aria-labelledby="productsEditDrop{{ $clientdevis->id }}down">
                                <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#editclientdevis{{ $clientdevis->id }}">
                                  <i class="bi-pencil-fill me-1 dropdown-item-icon"></i>Modifier la facture
                                </a>
                                <a  class="dropdown-item"
                                    @if($clientdevis->TDF == 2)
                                      href="{{ route('geststock.commercial.facture.client.prestation.deux', $clientdevis) }}">
                                    @else
                                      href="{{ route('geststock.commercial.facture.client.create.deux', $clientdevis) }}">
                                    @endif
                                  <i class="bi-pencil-fill me-1 dropdown-item-icon"></i>Modifier les @if($clientdevis->TDF == 2) prestations @else produits @endif
                                </a>
                                @php 
                                  $produit = null;
                                  $prestation = null;
                                  if($clientdevis->TDF != 2) { if($clientdevis->clientdevisprods->count() > 0) { $produit = 1; } }
                                  else { if($clientdevis->clientdevisprestations->count() > 0) { $prestation = 1; } }
                                @endphp
                                @if($produit || $prestation) 
                                  <a class="dropdown-item" href="{{ route('pdf.devis.commande.client', $clientdevis) }}" target="_blank">
                                    <i class="bi-file-earmark-arrow-down me-1 dropdown-item-icon"></i> PDF
                                  </a>
                                @endif
                                  <!-- <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#deleteclientdevis{{ $clientdevis->id }}">
                                    <i class="bi-trash dropdown-item-icon"></i>Supprimer la facture
                                  </a> -->
                              </div>
                            </div>
                            <!-- End Button Group -->
                          </div>
                        </td>
                      @endif
                      <td class="fw-bold">{{ $a }}</td>
                    </tr>

                    @include('include.commercial.clientdevis')
                  @endforeach
                </tbody>
              </table>
            </div>
            <!-- End Table -->

            <!-- Footer -->
              @include('dashboard.IncludePage.commun.pagination.pagination')
            <!-- End Footer -->
          @else
              <!-- Header -->
              <div class="card-header card-header-content-md-between p-4">
                <h3 class="fw-bold mb-0 text-center">Désolé! Aucune facture client établie sur la plateforme</h3>
              </div>
              <!-- End Header -->
          @endif
      </div>
      <!-- End Card -->
    </div>
    <!-- End Content -->
     
  </main>



@endsection