<?php

namespace App\Http\Controllers\Packauto;

use App\Models\Ppanne;
use App\Models\Pvehicule;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Http\Controllers\Controller;

class PackautoPanneController extends Controller
{
    //Panne
        public function panneEncours()
        {
            $ppannes = Ppanne::where('statut', 0)->orderBy('updated_at','desc')->get();
            return view('dashboard.packauto.panne.panne-en-attente', compact('ppannes'));
        }
        public function panneEntretenu()
        {
            $ppannes = Ppanne::where('statut', 1)->orderBy('updated_at','desc')->get();
            return view('dashboard.packauto.panne.panne-entretenu', compact('ppannes'));
        }
    //

    public function create()
    {
        //
    }
    
    public function store(Request $request)
    {
        $request->validate([
            'marque' => 'required|min:1',
            'modele' => 'required|min:1',
            'immatriculation' => 'required|unique:pvehicules|min:1',
            'annee' => 'nullable|min:1',
            'kilometrage' => 'nullable|min:1',
            'date_achat' => 'nullable|min:1',
            'statut' => 'required|in:actif,maintenance,vendu,accidenté',
            'photo' => 'nullable|mimes:png,jpg,jpeg,pdf',
            'pcategorievehicule_id' => 'required|min:1',
        ]);

        // Sauvegarde d'images
            $photo = null;
            if($request->hasFile('photo')){ $photo = storeImage($request->file('photo'), "VehiculePhoto"); }  
        //

        // Création du vehicule
            $pvehicule = Pvehicule::create([
                'marque' => $request->marque,
                'modele' => $request->modele,
                'immatriculation' => $request->immatriculation,
                'annee' => $request->annee,
                'kilometrage' => $request->kilometrage,
                'statut' => $request->statut,
                'date_achat' => $request->date_achat,
                'ES' => 1,
                'isvalide' => 1,
                'photo' => $photo,
                'pcategorievehicule_id' => $request->pcategorievehicule_id,
            ]);
        //

        return back()->with('success', "$pvehicule->marque ajouté avec succès");
    }

    public function show(Pvehicule $pvehicule)
    {
        return view('dashboard.packauto.vehicule.vehicule-document', compact('pvehicule'));
    }
    
    public function edit(string $id)
    {
        //
    }
    
    public function update(Request $request, Ppanne $ppanne)
    {
        $request->validate([
            'date_panne' => 'required|date',
            'description' => 'required|min:2',
            'pchauffeur_id' => 'required|exists:pchauffeurs,id',
            // 'employe_id' => 'required|exists:employes,id',
            'pvehicule_id' => 'required|exists:pvehicules,id',
        ]);
        
        // modifier l'emprunt
        $noms = $ppanne->pchauffeur->nom." ".$ppanne->pchauffeur->prenom;
        $ppanne->update($request->post());

        return back()->with('success', "Panne signalé par $noms modifié avec succes.");
    }

    public function destroy(Ppanne $ppanne)
    {
        $noms = "Panne signalé par ".$ppanne->pchauffeur->nom." ".$ppanne->pchauffeur->prenom." du ".$ppanne->created_at->format('d/m/Y H:i');
        $ppanne->delete();
        return back()->with('success',  "$noms supprimé avec succès");
    }
}
